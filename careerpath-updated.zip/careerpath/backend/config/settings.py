import os
import dj_database_url
from django.core.exceptions import ImproperlyConfigured
from datetime import timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-insecure-change-me")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = os.environ.get("ALLOWED_HOSTS", "*").split(",")
if not DEBUG and SECRET_KEY == "dev-insecure-change-me":
    raise ImproperlyConfigured("Set DJANGO_SECRET_KEY when DJANGO_DEBUG=0.")
HTTPS = os.environ.get("DJANGO_HTTPS", "0") == "1"   # set to 1 behind an HTTPS proxy (e.g. Render)
if HTTPS:
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https"); SESSION_COOKIE_SECURE = True; CSRF_COOKIE_SECURE = True
CSRF_TRUSTED_ORIGINS = [o for o in os.environ.get("CSRF_TRUSTED_ORIGINS", "").split(",") if o]
if os.environ.get("RENDER_EXTERNAL_URL"):   # set automatically by Render; lets /admin log in over https
    CSRF_TRUSTED_ORIGINS.append(os.environ["RENDER_EXTERNAL_URL"])
INSTALLED_APPS = [
    "django.contrib.admin", "django.contrib.auth", "django.contrib.contenttypes",
    "django.contrib.sessions", "django.contrib.messages", "django.contrib.staticfiles",
    "rest_framework", "corsheaders",
    "accounts", "careers", "assessments", "recommendations", "roadmaps", "rag", "assistant", "analytics",
]
MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
]
ROOT_URLCONF = "config.urls"
TEMPLATES = [{"BACKEND": "django.template.backends.django.DjangoTemplates", "DIRS": [], "APP_DIRS": True,
              "OPTIONS": {"context_processors": [
                  "django.template.context_processors.request",
                  "django.contrib.auth.context_processors.auth",
                  "django.contrib.messages.context_processors.messages"]}}]
if os.environ.get("DATABASE_URL"):   # hosted (Render etc.)
    DATABASES = {"default": dj_database_url.parse(os.environ["DATABASE_URL"], conn_max_age=600)}
elif os.environ.get("POSTGRES_HOST"):   # docker compose
    DATABASES = {"default": {"ENGINE": "django.db.backends.postgresql",
                             "NAME": os.environ.get("POSTGRES_DB", "careerpath"),
                             "USER": os.environ.get("POSTGRES_USER", "careerpath"),
                             "PASSWORD": os.environ.get("POSTGRES_PASSWORD", ""),
                             "HOST": os.environ["POSTGRES_HOST"], "PORT": os.environ.get("POSTGRES_PORT", "5432")}}
else:  # local dev / tests only
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": BASE_DIR / "db.sqlite3"}}
AUTH_USER_MODEL = "accounts.User"
AUTH_PASSWORD_VALIDATORS = [{"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
                            {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"}]
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": ["rest_framework_simplejwt.authentication.JWTAuthentication"],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_THROTTLE_CLASSES": ["rest_framework.throttling.AnonRateThrottle", "rest_framework.throttling.UserRateThrottle"],
    "DEFAULT_THROTTLE_RATES": {"anon": "60/min", "user": "300/min", "auth": "10/min", "llm": "20/min"},
}
SIMPLE_JWT = {"ACCESS_TOKEN_LIFETIME": timedelta(minutes=30), "REFRESH_TOKEN_LIFETIME": timedelta(days=7)}
CORS_ALLOWED_ORIGINS = list(dict.fromkeys([o.strip().rstrip("/") for o in os.environ.get("CORS_ORIGINS", "http://localhost:5173").split(",") if o.strip()]
                                           + [os.environ.get("FRONTEND_URL", "").rstrip("/")] * bool(os.environ.get("FRONTEND_URL"))))
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STORAGES = {"default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
            "staticfiles": {"BACKEND": "whitenoise.storage.CompressedStaticFilesStorage"}}
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ---- Email / password reset ----
FRONTEND_URL = os.environ.get("FRONTEND_URL", "http://localhost:5173")
PASSWORD_RESET_TIMEOUT = 3600   # reset links last 1 hour
DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "CareerPath AI <no-reply@careerpath.local>")
if os.environ.get("EMAIL_HOST"):
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_HOST = os.environ["EMAIL_HOST"]; EMAIL_PORT = int(os.environ.get("EMAIL_PORT", "587"))
    EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", ""); EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "")
    EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", "1") == "1"
    EMAIL_TIMEOUT = 10   # seconds; without this a blocked SMTP port can hang the request until gunicorn kills the worker
else:
    EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"   # emails are printed to the server log

# ---- Celery: real queue when CELERY_BROKER_URL (e.g. Redis) is set, otherwise tasks run inline ----
CELERY_BROKER_URL = os.environ.get("CELERY_BROKER_URL", "")
if not CELERY_BROKER_URL:
    CELERY_BROKER_URL = "memory://"; CELERY_TASK_ALWAYS_EAGER = True; CELERY_TASK_EAGER_PROPAGATES = True
